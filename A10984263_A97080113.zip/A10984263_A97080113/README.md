# Project 2
Authors: Lea Lacson and Heather Hua
Date: February 1, 2016

This program is an implementation of a GLSL Parser.

Extra Credit:
We have implemented the vec constructor for floating point values.